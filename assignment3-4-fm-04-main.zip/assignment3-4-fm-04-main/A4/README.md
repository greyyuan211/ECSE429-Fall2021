This is the template folder for ECSE 429 - Assignments 4.
---