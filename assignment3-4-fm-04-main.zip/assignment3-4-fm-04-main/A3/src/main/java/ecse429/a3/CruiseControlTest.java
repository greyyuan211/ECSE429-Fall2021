package ecse429.a3;

import ca.mcgill.ecse429.cruisecontrol.CruiseControllerStatus;
import ca.mcgill.ecse429.cruisecontrol.impl.CarControllerImpl;
import ca.mcgill.ecse429.cruisecontrol.impl.CruiseControllerImpl;

import org.junit.Assert;

import java.io.IOException;
import org.graphwalker.core.machine.ExecutionContext;
import org.graphwalker.java.annotation.GraphWalker;

@GraphWalker(value = "random(edge_coverage(100))", start = "v_Off" )
public class CruiseControlTest extends ExecutionContext implements CruiseControlModel {

    // Creating a CruiseControllerImpl object
    CruiseControllerImpl controller = new CruiseControllerImpl(new CarControllerImpl());
    
    @Override
    public void e_Cruise(){
        System.out.println("e_Cruise");
        controller.toggleCruise();
    }

    @Override
    public void e_Decel(){
        System.out.println("e_Decel");
        controller.setSpeedDecel();
    }

    @Override
    public void e_Accel(){
        System.out.println("e_Accel");
        controller.resumeCruiseAccel();
    }

    @Override
    public void e_Brake(){
        System.out.println("e_Brake");
        controller.brakeActivated();
    }

    @Override
    public void e_Cancel(){
        System.out.println("e_Cancel");
        controller.cancelCruise();
    }

    @Override
    public void v_Off(){
        Assert.assertTrue(controller.getCruiseControllerStatus() == CruiseControllerStatus.OFF);
        System.out.println("v_Off");
    }

    @Override
    public void v_Deactivated(){
        Assert.assertTrue(controller.getCruiseControllerStatus() == CruiseControllerStatus.PASSIVE);
        System.out.println("v_Deactivated");
    }

    @Override
    public void v_Activated(){
        Assert.assertTrue(controller.getCruiseControllerStatus() == CruiseControllerStatus.ACTIVE);
        System.out.println("v_Activated");
    }

    @Override
    public void v_Canceled(){
        System.out.println("!!!!!!!!!!!!");
        Assert.assertTrue(controller.getCruiseControllerStatus() == CruiseControllerStatus.CANCELLED);
        System.out.println("v_Canceled");
    }
}
